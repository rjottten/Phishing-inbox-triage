# phishing-inbox-triage

A Claude skill for exception-only review of a user-reported phishing queue.

Operating principle: Microsoft automation (Outlook Report button → Defender for Office 365 AIR + auto-notify → Security Copilot Phishing Triage Agent) handles routine classification and user feedback. Analysts handle exceptions — ambiguous verdicts, BEC, high-value targets, user interaction/compromise, and remediation decisions. The skill sorts every reported item into *handled by automation*, *automation gap*, or *exception*, works only the exceptions, and produces a prioritized handover report with recommended (never executed) response actions.

## Layout

```
phishing-inbox-triage/
├── SKILL.md                         # workflow, lanes, priorities, guardrails
├── references/
│   ├── exception-criteria.md        # tests for each exception category; when to disagree with AIR
│   ├── response-actions.md          # action matrix with decision owners
│   └── report-template.md           # shift report + single-message formats
├── scripts/
│   └── parse_headers.py             # raw headers → JSON (auth results, mismatches, flags)
└── evals/
    └── evals.json                   # test prompts
test-data/
└── mailbox_export.json              # synthetic 10-item queue (fictional domains) for testing
```

## Install

Zip the `phishing-inbox-triage/` folder (or use the packaged `.skill` file) and add it as a skill in Claude, or drop the folder into a Claude Code / Cowork skills directory.

## Header parser

```
python phishing-inbox-triage/scripts/parse_headers.py headers.txt
```

All test data is fictional. Never fetch URLs or open attachments from reported mail.
